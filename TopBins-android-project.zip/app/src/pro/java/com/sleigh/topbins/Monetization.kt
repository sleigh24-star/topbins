package com.sleigh.topbins

import android.app.Activity

/** PRO (paid) version: no ads SDK at all, no purchases, free continue every game. */
@Suppress("UNUSED_PARAMETER")
class Monetization(act: Activity, private val js: (String) -> Unit) {
    val isPro = true
    fun adsRemoved() = true
    fun price() = ""
    fun start() {}
    fun showInterstitial() {}
    fun showRewarded() { js("window.onRewarded&&window.onRewarded('ok')") }
    fun buyRemoveAds() {}
}
