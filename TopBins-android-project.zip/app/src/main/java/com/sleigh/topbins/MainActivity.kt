package com.sleigh.topbins

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var money: Monetization

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        hideBars()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
        }
        web.webViewClient = WebViewClient()

        money = Monetization(this) { js -> runOnUiThread { web.evaluateJavascript(js, null) } }
        web.addJavascriptInterface(Bridge(money), "TopBinsApp")
        web.loadUrl("file:///android_asset/index.html")
        money.start()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.tbBack&&window.tbBack())?'1':'0'") { r ->
                    if (r != "\"1\"") finish()
                }
            }
        })
    }

    private fun hideBars() {
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.hide(WindowInsetsCompat.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() { web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
}

/** Methods the game (index.html) can call as window.TopBinsApp.xxx() */
class Bridge(private val m: Monetization) {
    @JavascriptInterface fun isPro(): Boolean = m.isPro
    @JavascriptInterface fun adsRemoved(): Boolean = m.adsRemoved()
    @JavascriptInterface fun removeAdsPrice(): String = m.price()
    @JavascriptInterface fun showInterstitial() = m.showInterstitial()
    @JavascriptInterface fun showRewarded() = m.showRewarded()
    @JavascriptInterface fun buyRemoveAds() = m.buyRemoveAds()
}
