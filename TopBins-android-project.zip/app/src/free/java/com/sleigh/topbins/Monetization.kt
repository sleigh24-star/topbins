package com.sleigh.topbins

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * FREE version: AdMob interstitial + rewarded ads (with UK/EU consent via UMP)
 * and a one-off "remove_ads" in-app purchase through Google Play Billing.
 */
class Monetization(private val act: Activity, private val js: (String) -> Unit) {
    val isPro = false

    private val prefs = act.getSharedPreferences("topbins", Context.MODE_PRIVATE)
    @Volatile private var removed = prefs.getBoolean("ads_removed", false)
    @Volatile private var priceText = ""

    private var inter: InterstitialAd? = null
    private var rewarded: RewardedAd? = null
    private val adsStarted = AtomicBoolean(false)

    private lateinit var billing: BillingClient
    private var product: ProductDetails? = null

    private val interId get() = if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/1033173712" else BuildConfig.INTERSTITIAL_ID
    private val rewardId get() = if (BuildConfig.DEBUG) "ca-app-pub-3940256099942544/5224354917" else BuildConfig.REWARDED_ID

    fun adsRemoved() = removed
    fun price() = priceText

    fun start() {
        startBilling()
        if (!removed) startConsent()
    }

    /* ---------------- consent + ads ---------------- */
    private fun startConsent() {
        val ci = UserMessagingPlatform.getConsentInformation(act)
        ci.requestConsentInfoUpdate(
            act, ConsentRequestParameters.Builder().build(),
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(act) { _ ->
                    if (ci.canRequestAds()) initAds()
                }
            },
            { _ -> if (ci.canRequestAds()) initAds() }
        )
        if (ci.canRequestAds()) initAds()
    }

    private fun initAds() {
        if (!adsStarted.compareAndSet(false, true)) return
        act.runOnUiThread {
            MobileAds.initialize(act) {}
            loadInter()
            loadRewarded()
        }
    }

    private fun loadInter() {
        if (removed || !adsStarted.get()) return
        InterstitialAd.load(act, interId, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { inter = ad }
            override fun onAdFailedToLoad(e: LoadAdError) { inter = null }
        })
    }

    private fun loadRewarded() {
        if (removed || !adsStarted.get()) return
        RewardedAd.load(act, rewardId, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
            override fun onAdFailedToLoad(e: LoadAdError) { rewarded = null }
        })
    }

    fun showInterstitial() = act.runOnUiThread {
        if (removed) return@runOnUiThread
        val ad = inter ?: run { loadInter(); return@runOnUiThread }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { inter = null; loadInter() }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { inter = null; loadInter() }
        }
        ad.show(act)
    }

    /** Calls window.onRewarded('ok' | 'skip' | 'na') in the game. */
    fun showRewarded() = act.runOnUiThread {
        val ad = rewarded
        if (ad == null) {
            js("window.onRewarded&&window.onRewarded('na')")
            loadRewarded()
            return@runOnUiThread
        }
        var earned = false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewarded = null; loadRewarded()
                js("window.onRewarded&&window.onRewarded('${if (earned) "ok" else "skip"}')")
            }
            override fun onAdFailedToShowFullScreenContent(e: AdError) {
                rewarded = null; loadRewarded()
                js("window.onRewarded&&window.onRewarded('na')")
            }
        }
        ad.show(act) { _ -> earned = true }
    }

    /* ---------------- billing: remove_ads ---------------- */
    private fun startBilling() {
        billing = BillingClient.newBuilder(act)
            .setListener { result, purchases ->
                if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
                    purchases.forEach { handle(it) }
                } else if (result.responseCode == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
                    restore()
                }
            }
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .build()
        billing.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProduct(); restore()
                }
            }
            override fun onBillingServiceDisconnected() {}
        })
    }

    private fun queryProduct() {
        val params = QueryProductDetailsParams.newBuilder().setProductList(
            listOf(
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(PRODUCT_ID)
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build()
            )
        ).build()
        billing.queryProductDetailsAsync(params) { _, res ->
            product = res.productDetailsList.firstOrNull()
            priceText = product?.oneTimePurchaseOfferDetails?.formattedPrice ?: ""
            js("window.onPurchaseUpdated&&window.onPurchaseUpdated($removed)")
        }
    }

    private fun restore() {
        billing.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()
        ) { _, list -> list.forEach { handle(it) } }
    }

    private fun handle(p: Purchase) {
        if (!p.products.contains(PRODUCT_ID) || p.purchaseState != Purchase.PurchaseState.PURCHASED) return
        if (!p.isAcknowledged) {
            billing.acknowledgePurchase(
                AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()
            ) { _ -> }
        }
        removed = true
        prefs.edit().putBoolean("ads_removed", true).apply()
        inter = null
        js("window.onPurchaseUpdated&&window.onPurchaseUpdated(true)")
    }

    fun buyRemoveAds() = act.runOnUiThread {
        val pd = product
        if (pd == null || !billing.isReady) {
            js("window.onPurchaseUpdated&&window.onPurchaseUpdated(false,'unavailable')")
            return@runOnUiThread
        }
        val flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(
            listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).build())
        ).build()
        billing.launchBillingFlow(act, flow)
    }

    companion object { const val PRODUCT_ID = "remove_ads" }
}
