import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Google's public AdMob TEST ids. Debug builds always use these (never click your own real ads).
val testAppId = "ca-app-pub-3940256099942544~3347511713"
val testInterstitial = "ca-app-pub-3940256099942544/1033173712"
val testRewarded = "ca-app-pub-3940256099942544/5224354917"

fun envOr(name: String, def: String): String = System.getenv(name)?.takeIf { it.isNotBlank() } ?: def
fun q(s: String) = "\"$s\""

val signingFile = System.getenv("SIGNING_FILE")?.takeIf { it.isNotBlank() && file(it).exists() }
val runNumber = envOr("GITHUB_RUN_NUMBER", "1").toInt()

android {
    namespace = "com.sleigh.topbins"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.sleigh.topbins"
        minSdk = 26
        targetSdk = 36
        versionCode = runNumber
        versionName = "1.0.$runNumber"
    }

    buildFeatures { buildConfig = true }

    flavorDimensions += "tier"
    productFlavors {
        create("free") {
            dimension = "tier"
            resValue("string", "app_name", "Top Bins")
            buildConfigField("String", "INTERSTITIAL_ID", q(envOr("ADMOB_INTERSTITIAL_ID", testInterstitial)))
            buildConfigField("String", "REWARDED_ID", q(envOr("ADMOB_REWARDED_ID", testRewarded)))
        }
        create("pro") {
            dimension = "tier"
            applicationIdSuffix = ".pro"
            resValue("string", "app_name", "Top Bins Pro")
        }
    }

    signingConfigs {
        if (signingFile != null) {
            create("upload") {
                storeFile = file(signingFile)
                storePassword = System.getenv("SIGNING_PASSWORD")
                keyAlias = "upload"
                keyPassword = System.getenv("SIGNING_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            manifestPlaceholders["admobAppId"] = testAppId
        }
        release {
            isMinifyEnabled = false
            manifestPlaceholders["admobAppId"] = envOr("ADMOB_APP_ID", testAppId)
            if (signingFile != null) signingConfig = signingConfigs.getByName("upload")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    "freeImplementation"("com.google.android.gms:play-services-ads:24.4.0")
    "freeImplementation"("com.google.android.ump:user-messaging-platform:3.2.0")
    "freeImplementation"("com.android.billingclient:billing-ktx:8.0.0")
}
