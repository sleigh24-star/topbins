# Top Bins – free-kick football game (Android)

The game is `app/src/main/assets/index.html`. A Kotlin WebView wrapper (`MainActivity.kt`) runs it full-screen and links it to ads and billing.

## Two versions (product flavours)
| Flavour | Package | Money |
|---|---|---|
| `free` | `com.sleigh.topbins` | AdMob rewarded ad ("watch an ad to continue") + interstitial every 2nd game over, UK/EU consent screen (UMP), one-off in-app purchase `remove_ads` |
| `pro`  | `com.sleigh.topbins.pro` | Paid app on Play. No ads SDK, free continue every game |

## Building (no PC needed)
Every push to `main` runs **Actions → Build Android** and publishes a pre-release under **Releases** with:
- `TopBins-free-test.apk` / `TopBins-pro-test.apk` – install on your phone to test (debug builds always use Google's *test* ads)
- `TopBins-*-PLAYSTORE.aab` – signed bundles for Play Console (only once the upload key secrets are set)

## Going live – checklist
1. **Upload key**: Actions → *Make Play Store upload key* → Run. Download the artifact, add secrets `UPLOAD_KEYSTORE_BASE64` and `UPLOAD_KEYSTORE_PASSWORD`, save the .jks + password somewhere safe, delete the artifact.
2. **AdMob** (admob.google.com): create the app, then a Rewarded and an Interstitial ad unit. Add secrets `ADMOB_APP_ID`, `ADMOB_REWARDED_ID`, `ADMOB_INTERSTITIAL_ID`. Set up the GDPR consent message (Privacy & messaging).
3. **Play Console**: create both apps, upload the .aab files. Free app: Monetise → Products → In-app products → create `remove_ads` (e.g. £1.99). Pro app: set a price.
4. Add a privacy-policy URL, fill in Data safety (ads = advertising ID), and set the target audience to 13+ (not children).
